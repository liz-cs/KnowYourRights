export const environment = {
  production: false,
  baseUrl: "https://job-ionic-backend-app.herokuapp.com/api",
  ONESIGNAL_APP_ID: "xxxxxx-xxxxxx-xxxxxx-xxxxxx-xxxxxx",
  AD_UNIT_ID: "ca-app-pub-xxxxxxxxxxxx/xxxxxxxxxxxx",
  IS_TESTING: false
};
