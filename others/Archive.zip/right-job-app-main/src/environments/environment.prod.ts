export const environment = {
  production: true,
  baseUrl: "https://job-ionic-backend-app.herokuapp.com/api",
  ONESIGNAL_APP_ID: "b2f7f966-d8cc-11e4-bed1-df8f05be55ba",
  AD_UNIT_ID: "ca-app-pub-3940256099942544/1044960115",
  IS_TESTING: false
};