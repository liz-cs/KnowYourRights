import { Component } from "@angular/core";
import { OneSignal } from "@ionic-native/onesignal/ngx";
import { SplashScreen } from "@ionic-native/splash-screen/ngx";
import { StatusBar } from "@ionic-native/status-bar/ngx";
import { AlertController, Platform } from "@ionic/angular";
import { environment } from "src/environments/environment";
import { AdmobFreeService } from "./helpers/admobfree.service";
import { NetworkService, ConnectionStatus } from "./services/network.service";

@Component({
  selector: "app-root",
  templateUrl: "app.component.html",
  styleUrls: ["app.component.scss"],
})
export class AppComponent {
  public appPages = [
    {
      title: "Home",
      url: "/home",
      icon: "home",
    },
    {
      title: "Vacancies",
      url: "/post",
      icon: "briefcase",
    },
    {
      title: "Bookmarks",
      url: "/bookmark",
      icon: "bookmark",
    },
    {
      title: "About Us",
      url: "/about-us",
      icon: "information-circle",
    },
    {
      title: "Contact Us",
      url: "/contact-us",
      icon: "mail",
    },
    {
      title: "Terms & Conditions",
      url: "/term",
      icon: "document",
    },
  ];

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private alertCtrl: AlertController,
    private oneSignal: OneSignal,
    private admobFreeService: AdmobFreeService,
    private netWorkService: NetworkService
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.backgroundColorByHexString("#006c87");
      this.statusBar.styleLightContent();
      this.splashScreen.hide();
      //this.admobFreeService.BannerAd();
      //this.showInterstitial();

      if (this.platform.is("cordova")) {
        this.setupPush();
      } else {
        this.netWorkService.updateNetworkStatus(ConnectionStatus.Online);
      }
    });
  }

  setupPush() {
    this.oneSignal.startInit(environment.ONESIGNAL_APP_ID, "com.emehkeme");

    this.oneSignal.inFocusDisplaying(
      this.oneSignal.OSInFocusDisplayOption.None
    );

    this.oneSignal.handleNotificationReceived().subscribe((data) => {
      let msg = data.payload.body;
      let title = data.payload.title;
      let additionalData = data.payload.additionalData;
      this.showAlert(title, msg, additionalData.task);
    });

    this.oneSignal.handleNotificationOpened().subscribe((data) => {
      let additionalData = data.notification.payload.additionalData;

      this.showAlert(
        "Notification opened",
        "You already read this before",
        additionalData.task
      );
    });

    this.oneSignal.endInit();
  }

  async showAlert(title, msg, task) {
    const alert = await this.alertCtrl.create({
      header: title,
      subHeader: msg,
      buttons: [
        {
          text: `Action: ${task}`,
          handler: () => {},
        },
      ],
    });
    alert.present();
  }

  showInterstitial() {
    this.admobFreeService.InterstitialAd();
  }
}
