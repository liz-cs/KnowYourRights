import { BaseModel } from "./base.model";

export class Contact extends BaseModel {
  email: string;
  subject: string;
  message: string;
}
