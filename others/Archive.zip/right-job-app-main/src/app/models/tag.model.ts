import { BaseModel } from "./base.model";

export class Tag extends BaseModel {
  name: string;
}
