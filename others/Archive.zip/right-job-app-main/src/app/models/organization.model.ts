import { BaseModel } from "./base.model";

export class Organization extends BaseModel {
  title: string;
  name: string;
  description: string;
  country: string;
  city: string;
  address: string;
  phoneNumber: string;
  email: string;
}
