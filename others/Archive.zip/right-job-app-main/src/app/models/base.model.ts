export class BaseModel {
  _id: string;
  created_at: Date;
  updated_at: Date;
  createdUser: string;
  updatedUser: string;
  isActive: boolean;
  isDeleted: boolean;
}
