import { BaseModel } from "./base.model";

export class Category extends BaseModel {
  name: string;
}
