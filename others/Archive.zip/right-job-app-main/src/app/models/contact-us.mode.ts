import { BaseModel } from "./base.model";

export class ContactUs extends BaseModel {
  website: string;
  facebook: string;
  instagram: string;
  linkedin: string;
}
