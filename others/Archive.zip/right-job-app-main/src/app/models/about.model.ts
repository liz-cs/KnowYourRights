import { BaseModel } from "./base.model";

export class About extends BaseModel {
  title: string;
  content: string;
}
