import { BaseModel } from "./base.model";

export class Term extends BaseModel {
  content: string;
}
