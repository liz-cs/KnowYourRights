import { BaseModel } from "./base.model";

export class User extends BaseModel {
  email: string;
  username: string;
  passwordConfirm: string;
  password: string;
  firstName: string;
  lastName: string;
  role: string;
  gender: string;
}
