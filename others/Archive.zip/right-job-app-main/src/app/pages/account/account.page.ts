import { Component, OnInit } from "@angular/core";
import { AuthenticationService } from "src/app/services/authentication.service";
import { User } from "src/app/models/user.model";
import { AppService } from "src/app/services/app.service";

@Component({
  selector: "app-account",
  templateUrl: "./account.page.html",
  styleUrls: ["./account.page.scss"]
})
export class AccountPage implements OnInit {
  user: User;
  applies: any[];
  isLoading: boolean = true;

  constructor(
    private authService: AuthenticationService,
    private appService: AppService
  ) {}

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem("currentUser"));
    this.getApplies();
  }

  getApplies() {
    this.appService
      .post("/apply/getAppliesByUser", { user: this.user._id })
      .subscribe(res => {
        if (res["isSuccess"]) {
          this.applies = res["result"].data;
          this.isLoading = false;
        }
      });
  }

  logOut() {
    this.authService.logout();
  }
}
