import { Component, OnInit } from "@angular/core";
import {
  FormGroup,
  FormBuilder,
  FormControl,
  Validators
} from "@angular/forms";
import { User } from "src/app/models/user.model";
import { ToastService } from "src/app/helpers/toast.service";
import { AppService } from "src/app/services/app.service";

@Component({
  selector: "app-account-detail",
  templateUrl: "./account-detail.page.html",
  styleUrls: ["./account-detail.page.scss"]
})
export class AccountDetailPage implements OnInit {
  form: FormGroup;
  user: User;
  isLoading: boolean = true;

  constructor(
    private formBuilder: FormBuilder,
    private appService: AppService,
    private toastService: ToastService
  ) {}

  ngOnInit() {
    this.getUserDetail();
  }

  createForm() {
    this.form = this.formBuilder.group({
      email: new FormControl(this.user.email, [
        Validators.required,
        Validators.email
      ]),
      username: new FormControl(this.user.username, [Validators.required]),
      firstName: new FormControl(this.user.firstName, [Validators.required]),
      lastName: new FormControl(this.user.lastName, [Validators.required]),
      gender: new FormControl(this.user.gender, [Validators.required])
    });
  }

  getUserDetail() {
    this.appService.get("/user/getUserInfo").subscribe(res => {
      if (res["isSuccess"]) {
        this.user = res["data"].user as User;
        this.createForm();
        this.isLoading = false;
      }
    });
  }

  onProfileFormSubmit(values: any): void {
    if (this.form.valid) {
      this.isLoading = true;
      this.appService.patch(`/user/${this.user._id}`, values).subscribe(res => {
        if (!res["isSuccess"]) {
          this.toastService.presentSimpleToast("ERROR!");
          this.isLoading = false;
          return;
        }
        this.toastService.presentSimpleToast("Successfully updated!");
        this.isLoading = false;
      });
    }
  }
}
