import { Component, OnInit } from "@angular/core";
import { AppService } from "src/app/services/app.service";
import { About } from "src/app/models/about.model";

@Component({
  selector: "app-about-us",
  templateUrl: "./about-us.page.html",
  styleUrls: ["./about-us.page.scss"]
})
export class AboutUsPage implements OnInit {
  about: About;
  isLoading: boolean = true;

  constructor(
    private appService: AppService
  ) {}

  ngOnInit() {
    this.appService.get("/about").subscribe(res => {
      if (res["isSuccess"]) {
        this.about = res["result"].data[0] as About;
        this.isLoading = false;
      }
    });
  }
}
