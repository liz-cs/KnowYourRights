import { Component, OnInit, ViewChild } from "@angular/core";
import { AppService } from "src/app/services/app.service";
import { Post } from "src/app/models/post.model";

@Component({
  selector: "app-home",
  templateUrl: "./home.page.html",
  styleUrls: ["./home.page.scss"]
})
export class HomePage implements OnInit {
  postsPopular: Post[];
  posts: Post[];
  postCount: number = 0;
  applyCount: number = 0;
  isLoading: boolean = true;
  sliderConfig = {
    slidesPerView: 1.2,
    spaceBetween: 10,
    centeredSlides: false,
    autoplay: true
  };

  constructor(private appService: AppService) {}

  ngOnInit() {
    this.getPopularPosts();
    this.getRecentlyPosts();
    this.getApplyCount();
    this.getPostCount();
  }

  getPopularPosts() {
    this.appService.get("/post/popular").subscribe(res => {
      if (res["isSuccess"]) {
        this.postsPopular = res["result"].data as Post[];
      }
    });
  }

  getRecentlyPosts() {
    this.appService.get("/post/recently").subscribe(res => {
      if (res["isSuccess"]) {
        this.posts = res["result"].data as Post[];
        this.isLoading = false;
      }
    });
  }

  getApplyCount() {
    this.appService.get("/apply").subscribe(res => {
      if (res["isSuccess"]) {
        this.applyCount = res["result"].data.length;
      }
    });
  }

  getPostCount() {
    this.appService.post("/post/search", {}).subscribe(res => {
      if (res["isSuccess"]) {
        this.postCount = res["result"].data.length;
      }
    });
  }
}
