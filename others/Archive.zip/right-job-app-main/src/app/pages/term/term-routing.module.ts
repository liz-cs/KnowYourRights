import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { TermPage } from "./term.page";
import { IonicModule } from "@ionic/angular";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";

const routes: Routes = [
  {
    path: "",
    component: TermPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class TermPageRoutingModule {}
