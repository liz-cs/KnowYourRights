import { Component, OnInit } from "@angular/core";
import { Term } from "src/app/models/term.mode";
import { ActivatedRoute } from "@angular/router";
import { AppService } from "src/app/services/app.service";

@Component({
  selector: "app-term",
  templateUrl: "./term.page.html",
  styleUrls: ["./term.page.scss"]
})
export class TermPage implements OnInit {
  term: Term;
  isLoading: boolean = true;

  constructor(
    private activateRoute: ActivatedRoute,
    private appService: AppService
  ) {}

  ngOnInit() {
    this.appService.get("/about").subscribe(res => {
      if (res["isSuccess"]) {
        this.term = res["result"].data[2] as Term;
        this.isLoading = false;
      }
    });
  }
}
