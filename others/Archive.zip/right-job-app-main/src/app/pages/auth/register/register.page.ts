import { Component, OnInit } from "@angular/core";
import {
  FormBuilder,
  Validators,
  FormControl,
  FormGroup
} from "@angular/forms";
import { AuthenticationService } from "src/app/services/authentication.service";
import { Router } from "@angular/router";
import { matchingPasswords } from "src/app/shared/utils/app.validator";

@Component({
  selector: "app-register",
  templateUrl: "./register.page.html",
  styleUrls: ["./register.page.scss"]
})
export class RegisterPage implements OnInit {
  form: FormGroup;
  isLoading: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthenticationService,
    private router: Router
  ) {}

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.form = this.formBuilder.group(
      {
        username: new FormControl("", [Validators.required]),
        email: new FormControl("", [Validators.required, Validators.email]),
        password: [
          "",
          Validators.compose([Validators.required, Validators.minLength(6)])
        ],
        passwordConfirm: [
          "",
          Validators.compose([Validators.required, Validators.minLength(6)])
        ],
        firstName: new FormControl("", [Validators.required]),
        lastName: new FormControl("", [Validators.required]),
        gender: new FormControl("", [Validators.required])
      },
      { validator: matchingPasswords("password", "passwordConfirm") }
    );
  }

  onFormSubmit(values: Object) {
    if (this.form.valid) {
      this.isLoading = true;
      this.authService.register(values).then(() => {});
    }
  }
}
