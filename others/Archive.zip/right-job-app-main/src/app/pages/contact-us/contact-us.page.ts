import { Component, OnInit } from "@angular/core";
import {
  FormGroup,
  FormBuilder,
  FormControl,
  Validators
} from "@angular/forms";
import { AppService } from "src/app/services/app.service";
import { ToastService } from "src/app/helpers/toast.service";
import { ContactUs } from "src/app/models/contact-us.mode";

@Component({
  selector: "app-contact-us",
  templateUrl: "./contact-us.page.html",
  styleUrls: ["./contact-us.page.scss"]
})
export class ContactUsPage implements OnInit {
  form: FormGroup;
  contactUs: ContactUs;
  subjects: any[] = [
    { name: "Suggest" },
    { name: "Report" },
    { name: "Support" }
  ];
  isLoading: boolean = true;

  constructor(
    private formBuilder: FormBuilder,
    private appService: AppService,
    private toastService: ToastService
  ) {}

  ngOnInit() {
    this.getContactInformation();
    this.createForm();
  }

  createForm() {
    this.form = this.formBuilder.group({
      email: new FormControl("", [Validators.required, Validators.email]),
      subject: new FormControl("", [Validators.required]),
      message: new FormControl("", [Validators.required])
    });
  }

  onFormSubmit(values: any): void {
    if (this.form.valid) {
      this.isLoading = true;
      this.appService.post("/contact", values).subscribe(res => {
        this.toastService.presentSimpleToast("Message sent successfully!");
        this.isLoading = false;
      });
    }
  }

  getContactInformation() {
    this.appService.get(`/about`).subscribe(res => {
      if (res["result"]["data"][1]) {
        this.contactUs = res["result"]["data"][1] as ContactUs;
        this.isLoading = false;
      }
    });
  }
}
