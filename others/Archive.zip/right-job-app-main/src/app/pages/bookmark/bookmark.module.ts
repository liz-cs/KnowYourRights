import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { IonicModule } from "@ionic/angular";

import { BookmarkPageRoutingModule } from "./bookmark-routing.module";

import { BookmarkPage } from "./bookmark.page";
import { SharedModule } from "src/app/shared/shared.module";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BookmarkPageRoutingModule,
    ReactiveFormsModule,
    SharedModule
  ],
  declarations: [BookmarkPage]
})
export class BookmarkPageModule {}
