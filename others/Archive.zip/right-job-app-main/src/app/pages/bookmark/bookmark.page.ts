import { Component, OnInit } from "@angular/core";
import { Post } from "src/app/models/post.model";
import { ToastService } from "src/app/helpers/toast.service";

@Component({
  selector: "app-bookmark",
  templateUrl: "./bookmark.page.html",
  styleUrls: ["./bookmark.page.scss"]
})
export class BookmarkPage implements OnInit {
  posts: Post[];
  noData: boolean = false;

  constructor(private toastService: ToastService) {}

  ngOnInit() {
    this.getPosts();
  }

  getPosts() {
    let saved = JSON.parse(localStorage.getItem("bookmarks"));
    this.posts = saved;

    if (!this.posts) {
      this.noData = true;
    }
  }

  doRefresh(event) {
    setTimeout(() => {
      this.posts = null;
      this.getPosts();
      event.target.complete();
    }, 500);
  }

  clear() {
    localStorage.removeItem("bookmarks");
    this.toastService.presentSimpleToast("All bookmarks cleared!");
    this.getPosts();
  }
}
