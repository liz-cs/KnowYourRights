import { Component, OnInit } from "@angular/core";
import { Category } from "src/app/models/category.model";
import { AppService } from "src/app/services/app.service";

@Component({
  selector: "app-category",
  templateUrl: "./category.page.html",
  styleUrls: ["./category.page.scss"]
})
export class CategoryPage implements OnInit {
  categories: Category[];
  isLoading: boolean = true;

  constructor(private appService: AppService) {}

  ngOnInit() {
    this.appService.get("/category").subscribe(res => {
      if (res["isSuccess"]) {
        this.categories = res["result"].data as Category[];
        this.isLoading = false;
      }
    });
  }
}
