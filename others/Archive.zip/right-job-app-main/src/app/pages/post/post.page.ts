import { Component, OnInit } from "@angular/core";
import { Post } from "src/app/models/post.model";
import { AppService } from "src/app/services/app.service";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: "app-post",
  templateUrl: "./post.page.html",
  styleUrls: ["./post.page.scss"]
})
export class PostPage implements OnInit {
  posts: Post[];
  isSearchbar: boolean = false;
  isLoading: boolean = true;

  constructor(
    private appService: AppService,
    private activateRoute: ActivatedRoute
  ) {}

  ngOnInit() {
    this.getPosts();
  }

  getPosts() {
    let categoryId = this.activateRoute.snapshot.params["categoryId"];
    if (categoryId) {
      this.appService
        .post("/post/search", { category: categoryId })
        .subscribe(res => {
          if (res["isSuccess"]) {
            this.posts = res["result"].data as Post[];
            this.isLoading = false;
          }
        });
    } else {
      this.appService.post("/post/search", {}).subscribe(res => {
        if (res["isSuccess"]) {
          this.posts = res["result"].data as Post[];
          this.isLoading = false;
        }
      });
    }
  }

  searchPost(ev: any) {
    const val = ev.target.value;
    if (val && val.trim() != "") {
      this.appService
        .post("/post/getByTitle", { title: val })
        .subscribe(res => {
          if (res["isSuccess"]) {
            this.posts = res["result"].data as Post[];
          }
        });
    } else {
      this.getPosts();
    }
  }

  doRefresh(event) {
    setTimeout(() => {
      this.getPosts();
      event.target.complete();
    }, 2000);
  }
}
