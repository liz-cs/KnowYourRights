import { Component, OnInit } from "@angular/core";
import { AppService } from "src/app/services/app.service";
import { ActivatedRoute, Router } from "@angular/router";
import { Post } from "src/app/models/post.model";
import { ToastService } from "src/app/helpers/toast.service";
import { ShareService } from "src/app/helpers/share.service";

@Component({
  selector: "app-post-detail",
  templateUrl: "./post-detail.page.html",
  styleUrls: ["./post-detail.page.scss"]
})
export class PostDetailPage implements OnInit {
  post: Post;
  id: string;
  isLoading: boolean = true;

  constructor(
    private appService: AppService,
    private activateRoute: ActivatedRoute,
    private toastService: ToastService,
    private shareService: ShareService,
    private router: Router
  ) {}

  ngOnInit() {
    let id = this.activateRoute.snapshot.params["id"];
    if (id) {
      this.appService.getById(`/post/${id}`).subscribe(res => {
        if (res["isSuccess"]) {
          this.post = res["result"].data as Post;
          this.post.description = this.post.description.replace(/&lt;/g, "<"); //replace all
          this.incrementPostViewCount(id, this.post.viewCount);
          this.id = id;
          this.isLoading = false;
        }
      });
    }
  }

  incrementPostViewCount(id: string, currentViewCount: number) {
    currentViewCount++;
    this.appService
      .patch(`/post/${id}`, { viewCount: currentViewCount })
      .subscribe(result => {});
  }

  addBookmark() {
    let arr = [];
    let bookmarks = JSON.parse(localStorage.getItem("bookmarks"));

    if (bookmarks) {
      arr = bookmarks;
      if (arr.filter(v => v._id == this.id).length > 0) {
        this.toastService.presentSimpleToast("Post already added!");
        return;
      }
    }

    this.post._id = this.id;
    arr.push(this.post);
    localStorage.setItem("bookmarks", JSON.stringify(arr));
    this.toastService.presentSimpleToast("Successfully added!");
  }

  share() {
    this.shareService.share(this.post.title, "Rtjob");
  }

  apply() {
    if (!localStorage.getItem("token")) {
      this.router.navigate(["/login"]);
      return;
    }

    this.appService
      .post("/apply/checkDublicateByUser", {
        post: this.post._id,
        user: JSON.parse(localStorage.getItem("currentUser"))._id
      })
      .subscribe(res => {
        if (res["isSuccess"]) {
          if (res["result"]["data"].length > 0) {
            this.toastService.presentSimpleToast(
              "You are already applied this post!"
            );
          } else {
            this.insertApply();
          }
        }
      });
  }

  insertApply() {
    this.appService
      .post("/apply", {
        post: this.post._id,
        user: JSON.parse(localStorage.getItem("currentUser"))._id
      })
      .subscribe(res => {
        if (res["isSuccess"]) {
          this.toastService.presentSimpleToast("You are successfully applied!");
        }
      });
  }
}
