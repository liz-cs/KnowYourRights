import { NgModule } from "@angular/core";
import { PreloadAllModules, RouterModule, Routes } from "@angular/router";
import { AuthGuard } from "./pages/auth/auth.guard";

const routes: Routes = [
  {
    path: "",
    canActivate: [AuthGuard],
    redirectTo: "home",
    pathMatch: "full"
  },
  {
    path: "home",
    loadChildren: () =>
      import("./pages/home/home.module").then(m => m.HomePageModule)
  },
  {
    path: "about-us",
    loadChildren: () =>
      import("./pages/about-us/about-us.module").then(m => m.AboutUsPageModule)
  },
  {
    path: "contact-us",
    loadChildren: () =>
      import("./pages/contact-us/contact-us.module").then(
        m => m.ContactUsPageModule
      )
  },
  {
    path: "category",
    loadChildren: () =>
      import("./pages/category/category.module").then(m => m.CategoryPageModule)
  },
  {
    path: "account",
    canActivate: [AuthGuard],
    loadChildren: () =>
      import("./pages/account/account.module").then(m => m.AccountPageModule)
  },
  {
    path: "post",
    loadChildren: () =>
      import("./pages/post/post.module").then(m => m.PostPageModule)
  },
  {
    path: "post/:categoryId",
    loadChildren: () =>
      import("./pages/post/post.module").then(m => m.PostPageModule)
  },
  {
    path: "bookmark",
    loadChildren: () =>
      import("./pages/bookmark/bookmark.module").then(m => m.BookmarkPageModule)
  },
  {
    path: "term",
    loadChildren: () =>
      import("./pages/term/term.module").then(m => m.TermPageModule)
  },
  {
    path: "login",
    loadChildren: () =>
      import("./pages/auth/login/login.module").then(m => m.LoginPageModule)
  },
  {
    path: "register",
    loadChildren: () =>
      import("./pages/auth/register/register.module").then(
        m => m.RegisterPageModule
      )
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
