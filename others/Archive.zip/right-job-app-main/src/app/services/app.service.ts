import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { NativeStorage } from "@ionic-native/native-storage/ngx";
import { from, Observable } from "rxjs";
import { tap } from "rxjs/internal/operators/tap";
import { environment } from "../../environments/environment";
import { NetworkService, ConnectionStatus } from "./network.service";

const API_STORAGE_KEY = "jobPortal";

@Injectable({
  providedIn: "root",
})
export class AppService {
  // public baseUrl = (environment.production) ? environment.baseUrl : '';
  public baseUrl: string;
  constructor(
    public http: HttpClient,
    private netService: NetworkService,
    private nativeStorage: NativeStorage
  ) {
    this.baseUrl = environment.baseUrl;
  }

  public get(path): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl + path);
  }

  public getById(path): Observable<any> {
    return this.http.get<any>(this.baseUrl + path);
  }

  public post(path, object): Observable<any> {
    if (this.netService.getCurrentNetworkStatus() == ConnectionStatus.Offline) {
      // Return the cached data from Storage
      return from(this.getLocalData("posts"));
    } else {
      return this.http.post<any>(this.baseUrl + path, object).pipe(
        tap((res) => {
          this.setLocalData("posts", res);
        })
      );
    }
  }

  public put(path, object): Observable<any> {
    return this.http.put<any>(this.baseUrl + path, object);
  }

  public patch(path, object): Observable<any> {
    return this.http.patch<any>(this.baseUrl + path, object);
  }

  public getByParams(path, params: any): Observable<any> {
    return this.http.get<any[]>(this.baseUrl + path, { params: params });
  }

  public getPromise(path): Promise<any[]> {
    return this.http.get<any[]>(this.baseUrl + path).toPromise();
  }
  public getPromiseByParams(path, params): Promise<any[]> {
    return this.http
      .get<any[]>(this.baseUrl + path, { params: params })
      .toPromise();
  }

  private async setLocalData(key, data) {
    await this.nativeStorage.setItem(`${API_STORAGE_KEY}-${key}`, data);
  }

  private async getLocalData(key) {
    const data = await this.nativeStorage.getItem(`${API_STORAGE_KEY}-${key}`);
    return data;
  }
}
