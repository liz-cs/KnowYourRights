export const environment = {
  production: false,
  baseUrl: "https://job-ionic-backend-app.herokuapp.com/api",
  ONESIGNAL_APP_ID: "xxxxxxxxx-xxxxxxxxx-xxxxxxxxx-xxxxxxxxx-xxxxxxxxx",
  ONESIGNAL_REST_API_KEY: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
};
