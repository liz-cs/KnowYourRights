import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { map } from "rxjs/operators";
import { MatSnackBar } from "@angular/material/snack-bar";
import { Router } from "@angular/router";
import { environment } from "src/environments/environment.prod";

@Injectable({
  providedIn: "root"
})
export class AuthenticationService {
  public baseUrl: string;
  constructor(
    private http: HttpClient,
    public snackBar: MatSnackBar,
    public router: Router
  ) {
    this.baseUrl = environment.baseUrl;
  }

  public get currentUser() {
    return JSON.parse(localStorage.getItem("currentUser"));
  }

  public login(credentials) {
    return new Promise((resolve, reject) =>
      this.http
        .post(this.baseUrl + "/auth/login", credentials)
        .subscribe(res => {
          if (!res["isSuccess"]) {
            this.snackBar.open(res["error"]["message"], "×", {
              duration: 3000,
              verticalPosition: "top"
            });
            reject(false);
          } else {
            if (res["data"]["user"].role === "admin") {
              localStorage.setItem("token", res["token"]);
              resolve(true);
            } else {
              this.snackBar.open(
                "You have not permission to log as admin",
                "×",
                {
                  duration: 3000,
                  verticalPosition: "top"
                }
              );
              reject(false);
            }
          }
        })
    );
  }

  public logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("currentUser");
    this.router.navigate(["/auth/login"]);
  }

  public register(credentials) {
    return new Promise((resolve, reject) =>
      this.http
        .post(this.baseUrl + "/auth/signup", credentials)
        .subscribe(res => {
          if (!res["isSuccess"]) {
            this.snackBar.open(res["error"]["message"], "×", {
              duration: 3000,
              verticalPosition: "top"
            });
            reject(false);
          } else {
            this.snackBar.open("Successfully registered!", "×", {
              duration: 3000,
              verticalPosition: "top"
            });
            this.router.navigate(["/auth/login"]);
            resolve(true);
          }
        })
    );
  }

  public getCurrentUser() {
    return this.http.get(this.baseUrl + "/user/getUserInfo").subscribe(res => {
      if (!res["isSuccess"]) {
        this.snackBar.open("ERROR!", "×", {
          duration: 3000,
          verticalPosition: "top"
        });
      } else {
        localStorage.setItem(
          "currentUser",
          JSON.stringify(res["data"]["user"])
        );
      }
    });
  }

  // public hasAccess(claim: string) {
  //   this.currentUser.claims.includes(claim) ? true : false;
  // }
}
