import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Observable } from "rxjs";
import { environment } from "../../environments/environment";
import { MatSnackBar } from "@angular/material/snack-bar";

@Injectable({
  providedIn: "root",
})
export class AppService {
  // public baseUrl = (environment.production) ? environment.baseUrl : '';
  public baseUrl: string;
  constructor(public http: HttpClient, public snackBar: MatSnackBar) {
    this.baseUrl = environment.baseUrl;
  }

  public get(path): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl + path);
  }

  public getById(path): Observable<any> {
    return this.http.get<any>(this.baseUrl + path);
  }

  public post(path, object): Observable<any> {
    return this.http.post<any>(this.baseUrl + path, object);
  }

  public put(path, object): Observable<any> {
    return this.http.put<any>(this.baseUrl + path, object);
  }

  public patch(path, object): Observable<any> {
    return this.http.patch<any>(this.baseUrl + path, object);
  }

  public delete(path): Observable<any> {
    return this.http.delete<any>(this.baseUrl + path);
  }

  public getByParams(path, params: any): Observable<any> {
    return this.http.get<any[]>(this.baseUrl + path, { params: params });
  }

  public getPromise(path): Promise<any[]> {
    return this.http.get<any[]>(this.baseUrl + path).toPromise();
  }
  public getPromiseByParams(path, params): Promise<any[]> {
    return this.http
      .get<any[]>(this.baseUrl + path, { params: params })
      .toPromise();
  }

  uploadImage(file) {
    let formData = new FormData();
    formData.append("file", file);
    return this.http.post<any>(`${this.baseUrl}/asset/upload`, formData);
  }

  //public getFile(name: any) {
  //  return this.http.get("assets/files/" + name + ".ctmp", {
  //    responseType: "text"
  //  });
  //}
}
