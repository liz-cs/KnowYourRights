import { Component, OnInit, Output, EventEmitter } from "@angular/core";
import { Observable } from "rxjs";
import { AppComponent } from "src/app/app.component";
import { AuthenticationService } from "src/app/auth/authentication.service";

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"]
})
export class HeaderComponent implements OnInit {
  isLoggedIn$: Observable<boolean>;
  @Output("sideNav") sideNav: EventEmitter<boolean> = new EventEmitter();

  constructor(
    private authService: AuthenticationService,
    public RightSidenavComponent: AppComponent
  ) {}

  ngOnInit() {}

  onLogout() {
    //this.authService.logOut();
  }

  toggleSidenav() {
    this.sideNav.emit();
  }
}
