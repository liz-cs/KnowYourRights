import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppComponent } from "./app.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { PagesComponent } from "./pages/pages.component";
import { AppRouting } from "./app.routing";
import { SharedModule } from "./shared/shared.module";
import { NgMaterialMultilevelMenuModule } from "ng-material-multilevel-menu";
import { NotFoundComponent } from "./pages/not-found/not-found.component";
import { SidemenuComponent } from "./shared/components/sidemenu/sidemenu.component";
import { HeaderComponent } from "./shared/components/header/header.component";
import { ConfirmModalComponent } from "./shared/components/confirm-modal/confirm-modal.component";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { PostComponent } from "./pages/post/post.component";
import { CategoryComponent } from "./pages/category/category.component";
import { OrganizationComponent } from "./pages/organization/organization.component";
import { TagComponent } from "./pages/tag/tag.component";
import { LoginComponent } from "./pages/auth/login/login.component";
import { ReactiveFormsModule } from "@angular/forms";
import { AppInterceptor } from "./app.interceptor";
import { AccountComponent } from "./pages/account/account.component";
import { ContactComponent } from "./pages/contact/contact.component";
import { NgProgressModule } from "ngx-progressbar";
import { NgProgressHttpModule } from "ngx-progressbar/http";
import { UserComponent } from "./pages/user/user.component";
import { AboutUsComponent } from "./pages/about-us/about-us.component";

import { PerfectScrollbarModule } from "ngx-perfect-scrollbar";
import { PERFECT_SCROLLBAR_CONFIG } from "ngx-perfect-scrollbar";
import { PerfectScrollbarConfigInterface } from "ngx-perfect-scrollbar";
import { ContactUsComponent } from "./pages/contact-us/contact-us.component";
import { TermComponent } from "./pages/term/term.component";
import { MAT_SNACK_BAR_DEFAULT_OPTIONS } from "@angular/material/snack-bar";
import { RegisterComponent } from "./pages/auth/register/register.component";
import { ApplyComponent } from "./pages/apply/apply.component";
import { PushComponent } from "./pages/push/push.component";
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  wheelPropagation: false,
  suppressScrollX: true
};

@NgModule({
  declarations: [
    AppComponent,
    PagesComponent,
    NotFoundComponent,
    SidemenuComponent,
    HeaderComponent,
    ConfirmModalComponent,
    PostComponent,
    CategoryComponent,
    OrganizationComponent,
    TagComponent,
    LoginComponent,
    AccountComponent,
    ContactComponent,
    UserComponent,
    AboutUsComponent,
    ContactUsComponent,
    TermComponent,
    RegisterComponent,
    ApplyComponent,
    PushComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    AppRouting,
    SharedModule,
    PerfectScrollbarModule,
    NgMaterialMultilevelMenuModule,
    ReactiveFormsModule,
    NgProgressModule,
    NgProgressHttpModule
  ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    { provide: HTTP_INTERCEPTORS, useClass: AppInterceptor, multi: true },
    { provide: MAT_SNACK_BAR_DEFAULT_OPTIONS, useValue: { duration: 2500 } }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
