import { Component, OnInit } from "@angular/core";
import { User } from "src/app/models/user.model";
import {
  FormGroup,
  FormBuilder,
  FormControl,
  Validators
} from "@angular/forms";
import { AppService } from "src/app/services/app.service";
import { Router, ActivatedRoute } from "@angular/router";
import { MatSnackBar } from "@angular/material/snack-bar";

@Component({
  selector: "app-account",
  templateUrl: "./account.component.html",
  styleUrls: ["./account.component.css"]
})
export class AccountComponent implements OnInit {
  form: FormGroup;
  user: User = new User();

  constructor(
    private formBuilder: FormBuilder,
    private appService: AppService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.appService.getById(`/user/getUserInfo`).subscribe(res => {
      this.user = res.data.user as User;
      this.createForm();
    });
  }

  createForm() {
    this.form = this.formBuilder.group({
      _id: new FormControl(this.user._id),
      username: new FormControl(this.user.username, [Validators.required]),
      firstName: new FormControl(this.user.firstName, [Validators.required]),
      lastName: new FormControl(this.user.lastName, [Validators.required]),
      email: new FormControl(this.user.email, [
        Validators.required,
        Validators.email
      ]),
      gender: new FormControl(this.user.gender, [Validators.required]),
      role: new FormControl(this.user.role, [Validators.required])
    });
  }

  onFormSubmit(values): void {
    if (this.form.valid) {
      var model = values as User;
      this.appService.patch(`/user/${this.user._id}`, model).subscribe(res => {
        if (res.isSuccess) {
          this.router.navigate(["account"]);
          this.snackBar.open("Successfully updated!");
        } else {
          this.snackBar.open("Occured error!");
        }
      });
    }
  }
}
