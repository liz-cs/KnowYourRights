import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ContactDetailComponent } from "./contact-detail/contact-detail.component";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { SharedModule } from "src/app/shared/shared.module";
import { ContactComponent } from "./contact.component";

export const routes = [
  { path: "", component: ContactComponent, pathMatch: "full" }
];

@NgModule({
  declarations: [ContactDetailComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    SharedModule
  ],
  entryComponents: [ContactDetailComponent]
})
export class ContactModule {}
