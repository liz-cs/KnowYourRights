import { Component, OnInit, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { AppService } from "src/app/services/app.service";
import { Contact } from "src/app/models/contact.model";

@Component({
  selector: "app-contact-detail",
  templateUrl: "./contact-detail.component.html",
  styleUrls: ["./contact-detail.component.css"]
})
export class ContactDetailComponent implements OnInit {
  id: string;
  contact: Contact;

  constructor(
    private appService: AppService,
    public dialogRef: MatDialogRef<ContactDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.id = data.id;
  }

  ngOnInit(): void {
    this.getContactDetail();
  }

  getContactDetail() {
    this.appService.getById(`/contact/${this.id}`).subscribe(res => {
      if (!res["isSuccess"]) {
        //snackBar error
        return;
      }

      this.contact = res["result"]["data"] as Contact;
    });
  }

  closeModal(): void {
    this.dialogRef.close();
  }
}
