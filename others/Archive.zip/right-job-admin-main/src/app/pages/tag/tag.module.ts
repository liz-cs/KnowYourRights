import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { TagDetailComponent } from "./tag-detail/tag-detail.component";
import { TagComponent } from "./tag.component";
import { ReactiveFormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { SharedModule } from "src/app/shared/shared.module";

export const routes = [
  { path: "", component: TagComponent, pathMatch: "full" },
  {
    path: ":id",
    component: TagDetailComponent
  }
];

@NgModule({
  declarations: [TagDetailComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    SharedModule
  ],
  entryComponents: [TagDetailComponent]
})
export class TagModule {}
