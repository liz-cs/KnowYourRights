import { Component, OnInit, Inject } from "@angular/core";
import { Action } from "src/app/models/enums/action.enum";
import { Tag } from "src/app/models/tag.model";
import {
  FormControl,
  Validators,
  FormGroup,
  FormBuilder
} from "@angular/forms";
import { AppService } from "src/app/services/app.service";
import { MatSnackBar } from "@angular/material/snack-bar";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

@Component({
  selector: "app-tag-detail",
  templateUrl: "./tag-detail.component.html",
  styleUrls: ["./tag-detail.component.css"]
})
export class TagDetailComponent implements OnInit {
  id: string;
  form: FormGroup;
  tag: Tag = new Tag();
  action: Action;

  constructor(
    private appService: AppService,
    public dialogRef: MatDialogRef<TagDetailComponent>,
    private formBuilder: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private snackBar: MatSnackBar
  ) {
    this.id = data.id;
  }

  ngOnInit(): void {
    if (this.id) {
      this.appService.getById(`/tag/${this.id}`).subscribe(res => {
        this.tag = res.result.data as Tag;
        this.action = Action.Edit;
        this.createForm();
      });
    } else {
      this.action = Action.Create;
      this.createForm();
      this.form.setValue({ name: null, isActive: true });
    }
  }

  createForm() {
    this.form = this.formBuilder.group({
      name: new FormControl(this.tag.name, [Validators.required]),
      isActive: new FormControl(this.tag.isActive)
    });
  }

  onFormSubmit(values): void {
    if (this.form.valid) {
      var model = values as Tag;
      if (this.action == Action.Create) {
        model.isActive = true;
        this.appService.post("/tag", model).subscribe(res => {
          if (res.isSuccess) {
            this.closeModal(true);
            this.snackBar.open("Successfully added!");
          } else {
            this.snackBar.open("Occured error!");
          }
        });
      } else {
        this.appService.patch(`/tag/${this.tag._id}`, model).subscribe(res => {
          if (res.isSuccess) {
            this.closeModal(true);
            this.snackBar.open("Successfully updated!");
          } else {
            this.snackBar.open("Occured error!");
          }
        });
      }
    }
  }

  resetForm() {
    this.form.reset();
  }

  closeModal(val): void {
    this.dialogRef.close(val);
  }
}
