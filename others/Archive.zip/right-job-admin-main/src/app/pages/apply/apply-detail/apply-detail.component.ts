import { Component, OnInit, Inject } from "@angular/core";
import { Apply } from "src/app/models/apply.model";
import { AppService } from "src/app/services/app.service";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

@Component({
  selector: "app-apply-detail",
  templateUrl: "./apply-detail.component.html",
  styleUrls: ["./apply-detail.component.css"]
})
export class ApplyDetailComponent implements OnInit {
  id: string;
  apply: Apply;

  constructor(
    private appService: AppService,
    public dialogRef: MatDialogRef<ApplyDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.id = data.id;
  }

  ngOnInit(): void {
    this.getApplyDetail();
  }

  getApplyDetail() {
    this.appService.getById(`/apply/${this.id}`).subscribe(res => {
      if (!res["isSuccess"]) {
        //snackBar error
        return;
      }

      this.apply = res["result"]["data"] as Apply;
    });
  }

  closeModal(): void {
    this.dialogRef.close();
  }
}
