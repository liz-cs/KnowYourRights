import { Component, OnInit, ViewChild } from "@angular/core";
import { Apply } from "src/app/models/apply.model";
import { ConfirmModalComponent } from "src/app/shared/components/confirm-modal/confirm-modal.component";
import { ApplyDetailComponent } from "./apply-detail/apply-detail.component";
import { MatTableDataSource } from "@angular/material/table";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { AppService } from "src/app/services/app.service";
import { MatSnackBar } from "@angular/material/snack-bar";
import { MatDialog } from "@angular/material/dialog";

@Component({
  selector: "app-apply",
  templateUrl: "./apply.component.html",
  styleUrls: ["./apply.component.css"]
})
export class ApplyComponent implements OnInit {
  displayedColumns: string[] = [
    "title",
    "firstName",
    "lastName",
    "created_at",
    "status",
    "_id"
  ];
  dataSource: MatTableDataSource<Apply>;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private appService: AppService,
    private snackBar: MatSnackBar,
    public dialog: MatDialog
  ) {}

  ngOnInit() {
    this.getApplies();
  }

  getApplies() {
    this.appService.get("/apply").subscribe(result => {
      this.dataSource = new MatTableDataSource(result["result"].data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  openConfirmationDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmModalComponent, {
      width: "500px"
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.appService.delete(`/apply/${id}`).subscribe(res => {
          if (!res.isSuccess) {
            this.snackBar.open("Occured error!");
            return;
          }
          this.getApplies();
          this.snackBar.open("Successfully deleted!");
        });
      }
    });
  }

  openContactDetailModal(id: string): void {
    const dialogRef = this.dialog.open(ApplyDetailComponent, {
      data: { id: id },
      width: "800px"
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.dataSource = null;
        this.getApplies();
      }
    });
  }
}
