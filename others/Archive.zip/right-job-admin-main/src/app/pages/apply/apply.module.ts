import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { SharedModule } from "src/app/shared/shared.module";
import { ApplyDetailComponent } from "./apply-detail/apply-detail.component";
import { ApplyComponent } from "./apply.component";

export const routes = [
  { path: "", component: ApplyComponent, pathMatch: "full" }
];

@NgModule({
  declarations: [ApplyDetailComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    SharedModule
  ],
  entryComponents: [ApplyDetailComponent]
})
export class ApplyModule {}
