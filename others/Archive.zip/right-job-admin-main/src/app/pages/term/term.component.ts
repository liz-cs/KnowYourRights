import { Component, OnInit } from "@angular/core";
import { Action } from "src/app/models/enums/action.enum";
import { Term } from "src/app/models/term.model";
import {
  FormGroup,
  FormBuilder,
  FormControl,
  Validators
} from "@angular/forms";
import { AppService } from "src/app/services/app.service";
import { MatSnackBar } from "@angular/material/snack-bar";

@Component({
  selector: "app-term",
  templateUrl: "./term.component.html",
  styleUrls: ["./term.component.css"]
})
export class TermComponent implements OnInit {
  form: FormGroup;
  term: Term = new Term();
  action: Action;

  constructor(
    private formBuilder: FormBuilder,
    private appService: AppService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.getAbout();
  }

  getAbout() {
    this.appService.get(`/about`).subscribe(res => {
      if (res["result"]["data"][2]) {
        this.term = res["result"]["data"][2] as Term;
        this.createForm();
        this.action = Action.Edit;
      } else {
        this.createForm();
        this.action = Action.Create;
      }
    });
  }

  createForm() {
    this.form = this.formBuilder.group({
      content: new FormControl(this.term.content, [Validators.required])
    });
  }

  onFormSubmit(values): void {
    if (this.form.valid) {
      var model = values as Term;

      if (this.action === Action.Create) {
        this.appService.post(`/about`, model).subscribe(res => {
          if (res.isSuccess) {
            this.getAbout();
            this.snackBar.open("Successfully updated!");
          } else {
            this.snackBar.open("Occured error!");
          }
        });
      } else {
        this.appService
          .patch(`/about/${this.term._id}`, model)
          .subscribe(res => {
            if (res.isSuccess) {
              this.getAbout();
              this.snackBar.open("Successfully updated!");
            } else {
              this.snackBar.open("Occured error!");
            }
          });
      }
    }
  }
}
