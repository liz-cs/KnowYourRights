import { Component, OnInit, Inject } from "@angular/core";
import { Category } from "src/app/models/category.model";
import {
  FormGroup,
  FormBuilder,
  FormControl,
  Validators
} from "@angular/forms";
import { AppService } from "src/app/services/app.service";
import { MatSnackBar } from "@angular/material/snack-bar";
import { Action } from "src/app/models/enums/action.enum";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

@Component({
  selector: "app-category-detail",
  templateUrl: "./category-detail.component.html",
  styleUrls: ["./category-detail.component.css"]
})
export class CategoryDetailComponent implements OnInit {
  id: string;
  form: FormGroup;
  category: Category = new Category();
  action: Action;

  constructor(
    private appService: AppService,
    public dialogRef: MatDialogRef<CategoryDetailComponent>,
    private formBuilder: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private snackBar: MatSnackBar
  ) {
    this.id = data.id;
  }

  ngOnInit(): void {
    if (this.id) {
      this.appService.getById(`/category/${this.id}`).subscribe(res => {
        this.category = res.result.data as Category;
        this.action = Action.Edit;
        this.createForm();
      });
    } else {
      this.action = Action.Create;
      this.createForm();
      this.form.setValue({ name: null, isActive: true });
    }
  }

  createForm() {
    this.form = this.formBuilder.group({
      name: new FormControl(this.category.name, [Validators.required]),
      isActive: new FormControl(this.category.isActive)
    });
  }

  onFormSubmit(values): void {
    if (this.form.valid) {
      var model = values as Category;
      if (this.action == Action.Create) {
        model.isActive = true;
        this.appService.post("/category", model).subscribe(res => {
          if (res.isSuccess) {
            this.closeModal(true);
            this.snackBar.open("Successfully added!");
          } else {
            this.snackBar.open("Occured error!");
          }
        });
      } else {
        this.appService
          .patch(`/category/${this.category._id}`, model)
          .subscribe(res => {
            if (res.isSuccess) {
              this.closeModal(true);
              this.snackBar.open("Successfully updated!");
            } else {
              this.snackBar.open("Occured error!");
            }
          });
      }
    }
  }

  resetForm() {
    this.form.reset();
  }

  closeModal(val): void {
    this.dialogRef.close(val);
  }
}
