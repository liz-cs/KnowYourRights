import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { CategoryComponent } from "./category.component";
import { CategoryDetailComponent } from "./category-detail/category-detail.component";
import { ReactiveFormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { SharedModule } from "src/app/shared/shared.module";

export const routes = [
  { path: "", component: CategoryComponent, pathMatch: "full" },
  {
    path: ":id",
    component: CategoryDetailComponent
  }
];

@NgModule({
  declarations: [CategoryDetailComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    SharedModule
  ],
  entryComponents: [CategoryDetailComponent]
})
export class CategoryModule {}
