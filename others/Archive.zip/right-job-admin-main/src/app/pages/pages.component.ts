import { Component, OnInit, HostListener, ViewChild } from "@angular/core";
import { AuthenticationService } from "../auth/authentication.service";
import { AppService } from "../services/app.service";
import { Observable, Subscription } from "rxjs";
import { MediaObserver, MediaChange } from "@angular/flex-layout";
import { Router, NavigationEnd } from "@angular/router";
import { PerfectScrollbarDirective } from "ngx-perfect-scrollbar";

@Component({
  selector: "app-pages",
  templateUrl: "./pages.component.html",
  styleUrls: ["./pages.component.css"]
})
export class PagesComponent implements OnInit {
  isLoggedIn$: Observable<boolean>;
  opened = true;
  over = "side";
  expandHeight = "42px";
  collapseHeight = "42px";
  displayMode = "flat";
  watcher: Subscription;
  @ViewChild(PerfectScrollbarDirective, { static: true })
  perfectScroll: PerfectScrollbarDirective;

  constructor(
    media: MediaObserver,
    private authService: AuthenticationService,
    private router: Router
  ) {
    this.watcher = media.media$.subscribe((change: MediaChange) => {
      if (change.mqAlias === "sm" || change.mqAlias === "xs") {
        this.opened = false;
        this.over = "over";
      } else {
        this.opened = true;
        this.over = "side";
      }
    });

    this.router.events.subscribe(val => {
      if (val instanceof NavigationEnd) {
        this.perfectScroll.update();
      }
    });
  }

  ngOnInit() {
    //this.isLoggedIn$ = this.authService.isLoggedIn;
  }

  getSideNav() {
    if (this.opened) this.opened = false;
    else this.opened = true;
  }
}
