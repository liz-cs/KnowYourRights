import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule } from "@angular/forms";
import { SharedModule } from "src/app/shared/shared.module";
import { PushComponent } from "./push.component";
import { RouterModule } from "@angular/router";
import { AddPushComponent } from "./add-push/add-push.component";
import { DeviceComponent } from "./device/device.component";

export const routes = [
  { path: "", component: PushComponent, pathMatch: "full" },
  {
    path: "devices",
    component: DeviceComponent
  }
];

@NgModule({
  declarations: [AddPushComponent, DeviceComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ReactiveFormsModule,
    SharedModule
  ]
})
export class PushModule {}
