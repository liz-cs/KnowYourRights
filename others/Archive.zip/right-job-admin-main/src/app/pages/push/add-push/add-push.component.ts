import { Component, OnInit, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import {
  FormControl,
  FormBuilder,
  FormGroup,
  Validators
} from "@angular/forms";

@Component({
  selector: "app-add-push",
  templateUrl: "./add-push.component.html",
  styleUrls: ["./add-push.component.css"]
})
export class AddPushComponent implements OnInit {
  form: FormGroup;

  constructor(
    public dialogRef: MatDialogRef<AddPushComponent>,
    private formBuilder: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.form = this.formBuilder.group({
      header: new FormControl("", [Validators.required]),
      content: new FormControl("", [Validators.required])
    });
  }

  onFormSubmit(values) {
    if (this.form.valid) {
      this.dialogRef.close(values);
    }
  }
}
