import { Component, OnInit, ViewChild } from "@angular/core";
import { MatTableDataSource } from "@angular/material/table";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { PushService } from "src/app/helpers/push.service";

@Component({
  selector: "app-device",
  templateUrl: "./device.component.html",
  styleUrls: ["./device.component.css"]
})
export class DeviceComponent implements OnInit {
  displayedColumns: string[] = [
    "device_model",
    "game_version",
    "ip",
    "language",
    "created_at"
  ];
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;

  constructor(private pushService: PushService) {}

  ngOnInit() {
    this.getDevices();
  }

  getDevices() {
    this.pushService.getDevices().subscribe(data => {
      this.dataSource = new MatTableDataSource(data["players"]);
      setTimeout(() => {
        this.dataSource.filterPredicate = (
          data: { device_model: string },
          filterValue: string
        ) =>
          data.device_model
            .trim()
            .toLowerCase()
            .indexOf(filterValue) !== -1;

        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }, 100);
    });
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
