import { Component, OnInit, ViewChild } from "@angular/core";
import { MatTableDataSource } from "@angular/material/table";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { PushService } from "src/app/helpers/push.service";
import { MatDialog } from "@angular/material/dialog";
import { MatSnackBar } from "@angular/material/snack-bar";
import { AddPushComponent } from "./add-push/add-push.component";

@Component({
  selector: "app-push",
  templateUrl: "./push.component.html",
  styleUrls: ["./push.component.css"]
})
export class PushComponent implements OnInit {
  displayedColumns: string[] = ["headings.en", "contents.en", "successful"];
  dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  isLoading = false;

  constructor(
    private pushService: PushService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.getNotifications();
  }

  getNotifications() {
    this.pushService.getNotifications().subscribe(data => {
      this.dataSource = new MatTableDataSource(data["notifications"]);
      setTimeout(() => {
        this.dataSource.filterPredicate = (
          data: { en: string },
          filterValue: string
        ) =>
          data["headings"].en
            .trim()
            .toLowerCase()
            .indexOf(filterValue) !== -1;

        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }, 100);
      this.isLoading = true;
    });
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  newNotification() {
    const dialogRef = this.dialog.open(AddPushComponent, {
      width: "800px"
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.pushService.newNotifications(result["header"], result["content"]);
        this.getNotifications();
        this.snackBar.open("Successfully published!");
      }
    });
  }
}
