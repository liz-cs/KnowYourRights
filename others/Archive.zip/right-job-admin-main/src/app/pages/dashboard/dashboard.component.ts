import { Component, OnInit, ViewChild } from "@angular/core";
import { AppService } from "src/app/services/app.service";
import { Post } from "src/app/models/post.model";
import { MatTableDataSource } from "@angular/material/table";

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"]
})
export class DashboardComponent implements OnInit {
  postCount: number;
  userCount: number;
  categoryCount: number;
  applyCount: number;
  isLoading: boolean = false;
  hasPosts: boolean = false;
  posts: Post[];
  displayedColumns: string[] = [
    "title",
    "organization",
    "createdAt",
    "status",
    "_id"
  ];
  dataSource: MatTableDataSource<Post>;

  constructor(private appService: AppService) {}

  ngOnInit() {
    this.initItems();
  }

  initItems() {
    this.getPostCount();
    this.getUserCount();
    this.getCategoryCount();
    this.getApplyCount();
    this.getRecentlyPosts();
  }

  getPostCount() {
    this.appService.post("/post/search", {}).subscribe(result => {
      this.postCount = result["result"].data.length;
    });
  }

  getUserCount() {
    this.appService.get("/user").subscribe(result => {
      this.userCount = result["result"].data.length;
    });
  }

  getCategoryCount() {
    this.appService.get("/category").subscribe(result => {
      this.categoryCount = result["result"].data.length;
    });
  }

  getApplyCount() {
    this.appService.get("/apply").subscribe(result => {
      this.applyCount = result["result"].data.length;
    });
  }

  getRecentlyPosts() {
    this.isLoading = true;
    this.appService.get("/post/recently").subscribe(result => {
      this.dataSource = new MatTableDataSource(result["result"].data);
      this.isLoading = false;
      if (result["result"].data.length > 0) {
        this.hasPosts = true;
      }
    });
  }
}
