import { Component, OnInit } from "@angular/core";
import { About } from "src/app/models/about.model";
import {
  Validators,
  FormControl,
  FormGroup,
  FormBuilder
} from "@angular/forms";
import { AppService } from "src/app/services/app.service";
import { Router } from "@angular/router";
import { MatSnackBar } from "@angular/material/snack-bar";
import { Action } from "src/app/models/enums/action.enum";

@Component({
  selector: "app-about-us",
  templateUrl: "./about-us.component.html",
  styleUrls: ["./about-us.component.css"]
})
export class AboutUsComponent implements OnInit {
  form: FormGroup;
  about: About = new About();
  action: Action;

  constructor(
    private formBuilder: FormBuilder,
    private appService: AppService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.getAbout();
  }

  getAbout() {
    this.appService.get(`/about`).subscribe(res => {
      if (res["result"]["data"][0]) {
        this.about = res["result"]["data"][0] as About;
        this.createForm();
        this.action = Action.Edit;
      } else {
        this.createForm();
        this.action = Action.Create;
      }
    });
  }

  createForm() {
    this.form = this.formBuilder.group({
      title: new FormControl(this.about.title, [Validators.required]),
      content: new FormControl(this.about.content, [Validators.required])
    });
  }

  onFormSubmit(values): void {
    if (this.form.valid) {
      var model = values as About;

      if (this.action === Action.Create) {
        this.appService.post(`/about`, model).subscribe(res => {
          if (res.isSuccess) {
            this.getAbout();
            this.snackBar.open("Successfully updated!");
          } else {
            this.snackBar.open("Occured error!");
          }
        });
      } else {
        this.appService
          .patch(`/about/${this.about._id}`, model)
          .subscribe(res => {
            if (res.isSuccess) {
              this.getAbout();
              this.snackBar.open("Successfully updated!");
            } else {
              this.snackBar.open("Occured error!");
            }
          });
      }
    }
  }
}
