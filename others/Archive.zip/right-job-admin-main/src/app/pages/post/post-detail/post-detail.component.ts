import { Component, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import { MatSnackBar } from "@angular/material/snack-bar";
import { ActivatedRoute, Router } from "@angular/router";
import { Category } from "src/app/models/category.model";
import { Action } from "src/app/models/enums/action.enum";
import { Organization } from "src/app/models/organization.model";
import { Post } from "src/app/models/post.model";
import { Tag } from "src/app/models/tag.model";
import { AppService } from "src/app/services/app.service";

@Component({
  selector: "app-post-detail",
  templateUrl: "./post-detail.component.html",
  styleUrls: ["./post-detail.component.css"],
})
export class PostDetailComponent implements OnInit {
  form: FormGroup;
  post: Post = new Post();
  action: Action;
  categories: Category[];
  organizations: Organization[];
  tags: Tag[];
  jobTypes = [
    "Full-Time",
    "Part-Time",
    "Contact",
    "Temporary",
    "Internship",
    "Comission",
  ];
  editorStyle = {
    height: "200px",
  };

  constructor(
    private formBuilder: FormBuilder,
    private appService: AppService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.initItems();
    const id = this.activatedRoute.snapshot.paramMap.get("id");
    if (id !== "0") {
      this.appService.getById(`/post/${id}`).subscribe((res) => {
        this.post = res["result"].data as Post;
        this.action = Action.Edit;
        this.post.description = this.post.description.replace(/&lt;/g, "<"); //replace all
        this.createForm();
      });
    } else {
      this.action = Action.Create;
      this.createForm();
      this.form.patchValue({ viewCount: 0, isActive: true });
    }
  }

  initItems() {
    this.getCategories();
    this.getOrganizations();
    this.getTags();
  }

  createForm() {
    this.form = this.formBuilder.group({
      title: new FormControl(this.post.title, [Validators.required]),
      description: new FormControl(this.post.description),
      category: new FormControl(
        this.action == Action.Edit
          ? this.post.category["_id"]
          : this.post.category,
        [Validators.required]
      ),
      image: new FormControl(
        this.action == Action.Edit ? this.post.image : "",
        Validators.required
      ),
      jobType: new FormControl(this.post.jobType, [Validators.required]),
      organization: new FormControl(
        this.action == Action.Edit
          ? this.post.organization["_id"]
          : this.post.organization,
        [Validators.required]
      ),
      experience: new FormControl(this.post.experience, [Validators.required]),
      country: new FormControl(this.post.country, [Validators.required]),
      city: new FormControl(this.post.city, [Validators.required]),
      tags: new FormControl(
        this.action == Action.Edit
          ? this.post.tags.map((x) => x["_id"])
          : this.post.tags,
        [Validators.required]
      ),
      deadlineDate: new FormControl(this.post.deadlineDate, [
        Validators.required,
      ]),
      viewCount: new FormControl(this.post.viewCount, [Validators.required]),
      salary: new FormControl(this.post.salary, [
        Validators.required,
        Validators.pattern("^[0-9]+$"),
      ]),
      isActive: new FormControl(this.post.isActive, [Validators.required]),
    });
  }

  onFormSubmit(values): void {
    if (this.form.valid) {
      var model = values as Post;
      if (this.action == Action.Create) {
        this.appService.post("/post", model).subscribe((res) => {
          if (res.isSuccess) {
            this.router.navigate(["post"]);
            this.snackBar.open("Successfully added!");
          } else {
            this.snackBar.open("Occured error!");
          }
        });
      } else {
        this.appService
          .patch(`/post/${this.post._id}`, model)
          .subscribe((res) => {
            if (res.isSuccess) {
              this.router.navigate(["post"]);
              this.snackBar.open("Successfully updated!");
            } else {
              this.snackBar.open("Occured error!");
            }
          });
      }
    }
  }

  resetForm() {
    this.form.reset();
  }

  getCategories() {
    this.appService.get("/category").subscribe((res) => {
      this.categories = res["result"].data;
    });
  }

  getOrganizations() {
    this.appService.get("/organization").subscribe((res) => {
      this.organizations = res["result"].data;
    });
  }

  getTags() {
    this.appService.get("/tag").subscribe((res) => {
      this.tags = res["result"].data;
    });
  }

  uploadPostImage(event) {
    if (event && event.target.files) {
      this.appService.uploadImage(event.target.files[0]).subscribe((res) => {
        if (res && res.data) {
          this.form.patchValue({
            image: `http://localhost:4000/assets/${res.data.name}`,
          });
          this.snackBar.open("Successfully Uploaded!");
        }
      });
    }
  }
}
