import { Component, OnInit, ViewChild } from "@angular/core";
import { MatTableDataSource } from "@angular/material/table";
import { Post } from "src/app/models/post.model";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { AppService } from "src/app/services/app.service";
import { MatDialog } from "@angular/material/dialog";
import { ConfirmModalComponent } from "src/app/shared/components/confirm-modal/confirm-modal.component";
import { MatSnackBar } from "@angular/material/snack-bar";

@Component({
  selector: "app-post",
  templateUrl: "./post.component.html",
  styleUrls: ["./post.component.css"]
})
export class PostComponent implements OnInit {
  displayedColumns: string[] = [
    "title",
    "organization",
    "createdAt",
    "status",
    "_id"
  ];
  dataSource: MatTableDataSource<Post>;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private appService: AppService,
    private snackBar: MatSnackBar,
    public dialog: MatDialog
  ) {}

  ngOnInit() {
    this.getPosts();
  }

  getPosts() {
    this.appService.post("/post/search", {}).subscribe(result => {
      this.dataSource = new MatTableDataSource(result["result"].data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  openConfirmationDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmModalComponent, {
      width: "500px"
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.appService.delete(`/post/${id}`).subscribe(res => {
          if (!res.isSuccess) {
            this.snackBar.open("Occured error!");
            return;
          }
          this.getPosts();
          this.snackBar.open("Successfully deleted!");
        });
      }
    });
  }
}
