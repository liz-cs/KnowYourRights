import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { SharedModule } from "src/app/shared/shared.module";
import { PostComponent } from "./post.component";
import { PostDetailComponent } from "./post-detail/post-detail.component";
import { QuillModule } from "ngx-quill";

export const routes = [
  { path: "", component: PostComponent, pathMatch: "full" },
  {
    path: ":id",
    component: PostDetailComponent
  }
];

@NgModule({
  declarations: [PostDetailComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    SharedModule,
    QuillModule.forRoot()
  ]
})
export class PostModule {}
