import { Component, OnInit } from "@angular/core";
import { ContactUs } from "src/app/models/contact-us.model";
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder
} from "@angular/forms";
import { Action } from "src/app/models/enums/action.enum";
import { AppService } from "src/app/services/app.service";
import { MatSnackBar } from "@angular/material/snack-bar";

@Component({
  selector: "app-contact-us",
  templateUrl: "./contact-us.component.html",
  styleUrls: ["./contact-us.component.css"]
})
export class ContactUsComponent implements OnInit {
  form: FormGroup;
  contactUs: ContactUs = new ContactUs();
  action: Action;

  constructor(
    private formBuilder: FormBuilder,
    private appService: AppService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.getAboutContactUs();
  }

  getAboutContactUs() {
    this.appService.get(`/about`).subscribe(res => {
      if (res["result"]["data"][1]) {
        this.contactUs = res["result"]["data"][1] as ContactUs;
        this.createForm();
        this.action = Action.Edit;
      } else {
        this.createForm();
        this.action = Action.Create;
      }
    });
  }

  createForm() {
    this.form = this.formBuilder.group({
      website: new FormControl(this.contactUs.website, [Validators.required]),
      facebook: new FormControl(this.contactUs.facebook, [Validators.required]),
      instagram: new FormControl(this.contactUs.instagram, [
        Validators.required
      ]),
      linkedin: new FormControl(this.contactUs.linkedin, [Validators.required])
    });
  }

  onFormSubmit(values): void {
    if (this.form.valid) {
      var model = values as ContactUs;

      if (this.action === Action.Create) {
        this.appService.post(`/about`, model).subscribe(res => {
          if (res.isSuccess) {
            this.getAboutContactUs();
            this.snackBar.open("Successfully updated!");
          } else {
            this.snackBar.open("Occured error!");
          }
        });
      } else {
        this.appService
          .patch(`/about/${this.contactUs._id}`, model)
          .subscribe(res => {
            if (res.isSuccess) {
              this.getAboutContactUs();
              this.snackBar.open("Successfully updated!");
            } else {
              this.snackBar.open("Occured error!");
            }
          });
      }
    }
  }
}
