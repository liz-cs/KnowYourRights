import { Component, OnInit, Inject } from "@angular/core";
import { Organization } from "src/app/models/organization.model";
import {
  FormGroup,
  FormBuilder,
  FormControl,
  Validators
} from "@angular/forms";
import { AppService } from "src/app/services/app.service";
import { Router, ActivatedRoute } from "@angular/router";
import { MatSnackBar } from "@angular/material/snack-bar";
import { Action } from "src/app/models/enums/action.enum";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

@Component({
  selector: "app-organization-detail",
  templateUrl: "./organization-detail.component.html",
  styleUrls: ["./organization-detail.component.css"]
})
export class OrganizationDetailComponent implements OnInit {
  id: string;
  form: FormGroup;
  organization: Organization = new Organization();
  action: Action;

  constructor(
    private appService: AppService,
    public dialogRef: MatDialogRef<OrganizationDetailComponent>,
    private formBuilder: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private snackBar: MatSnackBar
  ) {
    this.id = data.id;
  }

  ngOnInit(): void {
    if (this.id) {
      this.appService.getById(`/organization/${this.id}`).subscribe(res => {
        this.organization = res.result.data as Organization;
        this.action = Action.Edit;
        this.createForm();
      });
    } else {
      this.action = Action.Create;
      this.createForm();
      this.form.setValue({
        name: null,
        address: null,
        country: null,
        city: null,
        email: null,
        phoneNumber: null,
        isActive: true
      });
    }
  }

  createForm() {
    this.form = this.formBuilder.group({
      name: new FormControl(this.organization.name, [Validators.required]),
      address: new FormControl(this.organization.address, [
        Validators.required
      ]),
      country: new FormControl(this.organization.country, [
        Validators.required
      ]),
      city: new FormControl(this.organization.city, [Validators.required]),
      phoneNumber: new FormControl(this.organization.phoneNumber, [
        Validators.required
      ]),
      email: new FormControl(this.organization.email, [
        Validators.required,
        Validators.email
      ]),
      isActive: new FormControl(this.organization.isActive)
    });
  }

  onFormSubmit(values): void {
    if (this.form.valid) {
      var model = values as Organization;

      if (this.action == Action.Create) {
        this.appService.post("/organization", model).subscribe(res => {
          if (res.isSuccess) {
            this.closeModal(true);
            this.snackBar.open("Successfully added!");
          } else {
            this.snackBar.open("Occured error!");
          }
        });
      } else {
        this.appService
          .patch(`/organization/${this.organization._id}`, model)
          .subscribe(res => {
            if (res.isSuccess) {
              this.closeModal(true);
              this.snackBar.open("Successfully updated!");
            } else {
              this.snackBar.open("Occured error!");
            }
          });
      }
    }
  }

  resetForm() {
    this.form.reset();
  }

  closeModal(val): void {
    this.dialogRef.close(val);
  }
}
