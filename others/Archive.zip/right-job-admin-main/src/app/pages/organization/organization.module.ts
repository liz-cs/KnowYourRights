import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { OrganizationComponent } from "./organization.component";
import { OrganizationDetailComponent } from "./organization-detail/organization-detail.component";
import { ReactiveFormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { SharedModule } from "src/app/shared/shared.module";

export const routes = [
  { path: "", component: OrganizationComponent, pathMatch: "full" },
  {
    path: ":id",
    component: OrganizationDetailComponent
  }
];

@NgModule({
  declarations: [OrganizationDetailComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    SharedModule
  ],
  entryComponents: [OrganizationDetailComponent]
})
export class OrganizationModule {}
