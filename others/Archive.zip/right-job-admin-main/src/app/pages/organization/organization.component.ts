import { Component, OnInit, ViewChild } from "@angular/core";
import { Organization } from "src/app/models/organization.model";
import { MatTableDataSource } from "@angular/material/table";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { AppService } from "src/app/services/app.service";
import { MatSnackBar } from "@angular/material/snack-bar";
import { MatDialog } from "@angular/material/dialog";
import { ConfirmModalComponent } from "src/app/shared/components/confirm-modal/confirm-modal.component";
import { OrganizationDetailComponent } from "./organization-detail/organization-detail.component";

@Component({
  selector: "app-organization",
  templateUrl: "./organization.component.html",
  styleUrls: ["./organization.component.css"]
})
export class OrganizationComponent implements OnInit {
  displayedColumns: string[] = ["name", "createdAt", "status", "_id"];
  dataSource: MatTableDataSource<Organization>;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private appService: AppService,
    private snackBar: MatSnackBar,
    public dialog: MatDialog
  ) {}

  ngOnInit() {
    this.getOrganizations();
  }

  getOrganizations() {
    this.appService.get("/organization").subscribe(result => {
      this.dataSource = new MatTableDataSource(result["result"].data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  openConfirmationDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmModalComponent, {
      width: "500px"
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.appService.delete(`/organization/${id}`).subscribe(res => {
          if (!res.isSuccess) {
            this.snackBar.open("Occured error!");
            return;
          }
          this.getOrganizations();
          this.snackBar.open("Successfully deleted!");
        });
      }
    });
  }

  openDetailModal(id: string): void {
    const dialogRef = this.dialog.open(OrganizationDetailComponent, {
      data: { id: id },
      width: "800px"
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.dataSource = null;
        this.getOrganizations();
      }
    });
  }
}
