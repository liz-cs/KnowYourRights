import { Component, OnInit } from "@angular/core";
import { AuthenticationService } from "src/app/auth/authentication.service";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { emailValidator } from "src/app/shared/utils/app.validator";
import { Router } from "@angular/router";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  form: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthenticationService,
    private router: Router
  ) {}

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.form = this.formBuilder.group({
      email: ["", Validators.compose([Validators.required, emailValidator])],
      password: [
        "",
        Validators.compose([Validators.required, Validators.minLength(6)])
      ]
    });
  }

  onFormSubmit(values: Object) {
    if (this.form.valid) {
      this.authService.login(values).then(result => {
        if (result) {
          this.authService.getCurrentUser();
          this.router.navigateByUrl("/");
        }
      });
    }
  }
}
