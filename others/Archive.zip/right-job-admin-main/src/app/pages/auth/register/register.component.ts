import { Component, OnInit } from "@angular/core";
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from "@angular/forms";
import { matchingPasswords } from "src/app/shared/utils/app.validator";
import { AuthenticationService } from "src/app/auth/authentication.service";

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"]
})
export class RegisterComponent implements OnInit {
  form: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthenticationService
  ) {}

  ngOnInit(): void {
    this.createForm();
  }

  createForm() {
    this.form = this.formBuilder.group(
      {
        username: new FormControl("", [Validators.required]),
        email: new FormControl("", [Validators.required, Validators.email]),
        password: [
          "",
          Validators.compose([Validators.required, Validators.minLength(6)])
        ],
        passwordConfirm: [
          "",
          Validators.compose([Validators.required, Validators.minLength(6)])
        ],
        firstName: new FormControl("", [Validators.required]),
        lastName: new FormControl("", [Validators.required]),
        gender: new FormControl("", [Validators.required]),
        role: new FormControl("admin", [Validators.required])
      },
      { validator: matchingPasswords("password", "passwordConfirm") }
    );
  }

  onFormSubmit(values: Object) {
    if (this.form.valid) {
      this.authService.register(values).then(() => {});
    }
  }
}
