import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { UserDetailComponent } from "./user-detail/user-detail.component";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { SharedModule } from "src/app/shared/shared.module";
import { UserComponent } from "./user.component";

export const routes = [
  { path: "", component: UserComponent, pathMatch: "full" }
];

@NgModule({
  declarations: [UserDetailComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    SharedModule
  ],
  entryComponents: [UserDetailComponent]
})
export class UserModule {}
