import { Component, OnInit, Inject } from "@angular/core";
import { AppService } from "src/app/services/app.service";
import { User } from "src/app/models/user.model";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ContactDetailComponent } from "../../contact/contact-detail/contact-detail.component";
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder
} from "@angular/forms";
import { MatSnackBar } from "@angular/material/snack-bar";

@Component({
  selector: "app-user-detail",
  templateUrl: "./user-detail.component.html",
  styleUrls: ["./user-detail.component.css"]
})
export class UserDetailComponent implements OnInit {
  id: string;
  form: FormGroup;
  user: User = new User();

  constructor(
    private appService: AppService,
    public dialogRef: MatDialogRef<ContactDetailComponent>,
    private formBuilder: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private snackBar: MatSnackBar
  ) {
    this.id = data.id;
  }

  ngOnInit(): void {
    this.getUserDetail();
  }

  createForm() {
    this.form = this.formBuilder.group({
      _id: new FormControl(this.user._id),
      username: new FormControl(this.user.username, [Validators.required]),
      firstName: new FormControl(this.user.firstName, [Validators.required]),
      lastName: new FormControl(this.user.lastName, [Validators.required]),
      email: new FormControl({ value: this.user.email, disabled: true }, [
        Validators.required,
        Validators.email
      ]),
      gender: new FormControl(this.user.gender, [Validators.required]),
      role: new FormControl({ value: this.user.role, disabled: true }, [
        Validators.required
      ]),
      isActive: new FormControl(this.user.isActive, [Validators.required])
    });
  }

  getUserDetail() {
    this.appService.getById(`/user/${this.id}`).subscribe(res => {
      if (!res["isSuccess"]) {
        //snackBar error
        return;
      }
      this.user = res["result"]["data"] as User;
      this.createForm();
    });
  }

  onFormSubmit(values): void {
    if (this.form.valid) {
      var model = values as User;
      this.appService.patch(`/user/${this.user._id}`, model).subscribe(res => {
        if (res.isSuccess) {
          this.closeModal(true);
          this.snackBar.open("Successfully updated!");
        } else {
          this.snackBar.open("Occured error!");
        }
      });
    }
  }

  closeModal(val): void {
    this.dialogRef.close(val);
  }
}
