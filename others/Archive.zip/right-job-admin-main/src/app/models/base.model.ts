export class BaseModel {
  _id: string;
  created_at: Date;
  updated_at: Date;
  isActive: boolean;
  isDeleted: boolean;
}
