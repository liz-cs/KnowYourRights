import { BaseModel } from "./base.model";

export class User extends BaseModel {
  username: string;
  password: string;
  passwordConfirm: string;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  gender: string;
}
