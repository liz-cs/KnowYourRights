import { BaseModel } from "./base.model";
import { Organization } from "./organization.model";
import { Category } from "./category.model";

export class Post extends BaseModel {
  category: Category;
  image: string;
  title: string;
  description: string;
  organization: Organization[];
  experience: string;
  country: string;
  city: string;
  tags: string[];
  viewCount: number;
  deadlineDate: Date;
  jobType: string;
  salary: number;
}
