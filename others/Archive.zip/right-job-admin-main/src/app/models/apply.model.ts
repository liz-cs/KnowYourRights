import { BaseModel } from "./base.model";
import { Post } from "./post.model";
import { User } from "./user.model";

export class Apply extends BaseModel {
  post: Post;
  user: User;
}
