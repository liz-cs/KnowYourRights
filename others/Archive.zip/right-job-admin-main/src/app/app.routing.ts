import { Routes, RouterModule, PreloadAllModules } from "@angular/router";
import { ModuleWithProviders } from "@angular/core";

import { PagesComponent } from "./pages/pages.component";
import { AuthenticationGuard } from "./auth/authentication.guard";
import { NotFoundComponent } from "./pages/not-found/not-found.component";
import { LoginComponent } from "./pages/auth/login/login.component";
import { RegisterComponent } from "./pages/auth/register/register.component";

export const routes: Routes = [
  {
    path: "",
    canActivate: [AuthenticationGuard],
    component: PagesComponent,
    children: [
      { path: "", redirectTo: "dashboard", pathMatch: "full" },
      {
        path: "dashboard",
        loadChildren: () =>
          import("./pages/dashboard/dashboard.module").then(
            m => m.DashboardModule
          )
      },
      {
        path: "post",
        loadChildren: () =>
          import("./pages/post/post.module").then(m => m.PostModule)
      },
      {
        path: "category",
        loadChildren: () =>
          import("./pages/category/category.module").then(m => m.CategoryModule)
      },
      {
        path: "user",
        loadChildren: () =>
          import("./pages/user/user.module").then(m => m.UserModule)
      },
      {
        path: "apply-history",
        loadChildren: () =>
          import("./pages/apply/apply.module").then(m => m.ApplyModule)
      },
      {
        path: "push",
        loadChildren: () =>
          import("./pages/push/push.module").then(m => m.PushModule)
      },
      {
        path: "organization",
        loadChildren: () =>
          import("./pages/organization/organization.module").then(
            m => m.OrganizationModule
          )
      },
      {
        path: "tag",
        loadChildren: () =>
          import("./pages/tag/tag.module").then(m => m.TagModule)
      },
      {
        path: "contact",
        loadChildren: () =>
          import("./pages/contact/contact.module").then(m => m.ContactModule)
      },
      {
        path: "about-us",
        loadChildren: () =>
          import("./pages/about-us/about-us.module").then(m => m.AboutUsModule)
      },
      {
        path: "contact-us",
        loadChildren: () =>
          import("./pages/contact-us/contact-us.module").then(
            m => m.ContactUsModule
          )
      },
      {
        path: "term",
        loadChildren: () =>
          import("./pages/term/term.module").then(m => m.TermModule)
      },
      {
        path: "account",
        loadChildren: () =>
          import("./pages/account/account.module").then(m => m.AccountModule)
      }
    ]
  },
  {
    path: "auth/login",
    component: LoginComponent
  },
  {
    path: "auth/register",
    component: RegisterComponent
  },
  { path: "**", component: NotFoundComponent }
];

export const AppRouting: ModuleWithProviders = RouterModule.forRoot(routes, {
  preloadingStrategy: PreloadAllModules // <- comment this line for activate lazy load
  // useHash: true
});
