const express = require("express");
const router = express.Router();
const contactController = require("../controllers/contactController");
const authController = require("../controllers/authController");

router.route("/").post(contactController.insertContact);
//auth
router.use(authController.protect);
//admin
router.use(authController.restrictTo("admin"));
router.route("/").get(contactController.getAllContacts);
router
  .route("/:id")
  .get(contactController.getContact)
  .patch(contactController.updateContact)
  .delete(contactController.deleteContact);

module.exports = router;
