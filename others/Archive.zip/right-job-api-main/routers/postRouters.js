const express = require("express");
const router = express.Router();
const postController = require("../controllers/postController");
const authController = require("../controllers/authController");

router.route("/search").post(postController.getPostsByFilter);
router.route("/getByTitle").post(postController.getPostsByTitle);
router.route("/popular").get(postController.getPostsPopular);
router.route("/recently").get(postController.getPostsRecently);
router.route("/:id").get(postController.getPost);
router.route("/:id").patch(postController.updatePost);

//auth
router.use(authController.protect);
//admin
router.use(authController.restrictTo("admin"));
router.route("/").post(postController.insertPost);
router.route("/:id").delete(postController.deletePost);

module.exports = router;
