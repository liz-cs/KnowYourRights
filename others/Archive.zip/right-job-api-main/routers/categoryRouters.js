const express = require("express");
const router = express.Router();
const categoryController = require("../controllers/categoryController");
const authController = require("../controllers/authController");

router.route("/").get(categoryController.getAllCategories);
router.route("/:id").get(categoryController.getCategory);

//auth
//router.use(authController.protect);

//admin
//router.use(authController.restrictTo("admin"));
router.route("/").post(categoryController.insertCategory);
router
  .route("/:id")
  .patch(categoryController.updateCategory)
  .delete(categoryController.deleteCategory);

module.exports = router;
