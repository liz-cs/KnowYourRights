const express = require("express");
const router = express.Router();

var multipart = require('connect-multiparty');

const authController = require("../controllers/authController");
const fileController = require("../controllers/fileController")
//auth
router.use(authController.protect);
// file handler ..
router.route("/upload").post(fileController.upload);
router.route("/read").get(fileController.read);

module.exports = router;
