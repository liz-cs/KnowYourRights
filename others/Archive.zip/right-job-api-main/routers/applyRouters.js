const express = require("express");
const router = express.Router();
const applyController = require("../controllers/applyController");
const authController = require("../controllers/authController");

router.route("/").get(applyController.getAllApply);
router.route("/checkDublicateByUser").post(applyController.checkDublicateApplyByUser);
router.route("/getAppliesByUser").post(applyController.getAppliesByUser);
router.route("/:id").get(applyController.getApply);

//auth
router.use(authController.protect);
router.route("/").post(applyController.insertApply);

//admin
router.use(authController.restrictTo("admin"));

router.route("/:id").patch(applyController.updateApply);
router.route("/:id").delete(applyController.deleteApply);

module.exports = router;
