const express = require("express");
const router = express.Router();
const tagController = require("../controllers/tagController");
const authController = require("../controllers/authController");

router.route("/").get(tagController.getAllTags);
router.route("/").post(tagController.insertTag);

//auth
router.use(authController.protect);
//admin
router.use(authController.restrictTo("admin"));

router.route("/:id").get(tagController.getTag);
router.route("/:id").patch(tagController.updateTag);
router.route("/:id").delete(tagController.deleteTag);

module.exports = router;
