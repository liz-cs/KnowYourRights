const express = require("express");
const router = express.Router();
const organizationController = require("../controllers/organizationController");
const authController = require("../controllers/authController");

//auth
//router.use(authController.protect);
//admin
//router.use(authController.restrictTo("admin"));
router.route("/").get(organizationController.getAllOrganizations);
router.route("/").post(organizationController.insertOrganization);
router.route("/:id")
    .get(organizationController.getOrganization)
    .patch(organizationController.updateOrganization)
    .delete(organizationController.deleteOrganization);

module.exports = router;