const express = require("express");
const router = express.Router();
const aboutController = require("../controllers/aboutController");
const authController = require("../controllers/authController");

router.route("/").get(aboutController.getAllAbouts);

//auth
router.use(authController.protect);
//admin
router.use(authController.restrictTo("admin"));
router.route("/").post(aboutController.insertAbout);
router
  .route("/:id")
  .get(aboutController.getAbout)
  .patch(aboutController.updateAbout)
  .delete(aboutController.deleteAbout);

module.exports = router;
