const mongoose = require("mongoose");
const baseModel = require("./baseModel");
const validator = require("validator");

var contactSchema = new baseModel({
  email: {
    type: String,
    required: [true, "Email is required"],
    validate: [validator.isEmail, "Please provide a valid email address"]
  },
  subject: {
    type: String,
    required: [true, "Subject is required"]
  },
  message: {
    type: String,
    required: [true, "Message is required"]
  }
});

const Contact = mongoose.model("Contact", contactSchema);
module.exports = Contact;
