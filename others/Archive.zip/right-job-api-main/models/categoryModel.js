const mongoose = require("mongoose");
const baseModel = require('./baseModel');

var categorySchema = new baseModel({
    name: {
        type: String,
        required: [true, "Category name is required"]
    }
})

const Category = mongoose.model("Category", categorySchema);
module.exports = Category;