const mongoose = require("mongoose");
const validator = require("validator");
const baseModel = require("./baseModel");

var organizationSchema = new baseModel({
  name: {
    type: String,
    required: [true, "Organization name is required"]
  },
  country: {
    type: String,
    required: [true, "Organization country is required"]
  },
  city: {
    type: String,
    required: [true, "Organization city is required"]
  },
  address: {
    type: String,
    required: [true, "Organization address is required"]
  },
  imageUrl: {
    type: String
  },
  phoneNumber: [
    {
      type: String,
      required: [true, "Organization phone number is required"]
    }
  ],
  email: {
    type: String,
    required: [true, "Organization email is required"],
    lowercase: true,
    validate: [validator.isEmail, "Please provide a valid email address"]
  },
  location: {
    type: String
  }
});

const Organization = mongoose.model("Organization", organizationSchema);
module.exports = Organization;
