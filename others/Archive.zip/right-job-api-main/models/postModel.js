const mongoose = require("mongoose");
const baseModel = require("./baseModel");

var postSchema = new baseModel(
  {
    category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Category"
    },
    image:{
      type:String
    },
    title: {
      type: String,
      required: [true, "Title is required"]
    },
    description: {
      type: String,
      required: [true, "Description is required"]
    },
    salary: {
      type: Number,
      required: [true, "Salary is required"]
    },
    experience: {
      type: String,
      required: [true, "Experience is required"]
    },
    country: {
      type: String,
      required: [true, "Country is required"]
    },
    city: {
      type: String,
      required: [true, "City is required"]
    },
    viewCount: {
      type: Number,
      required: [true, "City is required"]
    },
    deadlineDate: {
      type: Date,
      required: [true, "City is required"]
    },
    jobType: {
      type: String,
      required: [true, "Job type is required"]
    },
    organization: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Organization",
      required: [true, "Organization is required"]
    },
    tags: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Tag"
      }
    ],
    role: {
      type: String,
      enum: ["admin", "recruiter", "user"],
      default: "user"
    }
  },
  { versionKey: false }
);

/*
postSchema.pre("save", async function (next) {
  
  next();
})
*/

var autoPopulatePost = function(next) {
  this.populate("organization");
  this.populate("category");
  this.populate("tags");
  next();
};

postSchema.pre("findOne", autoPopulatePost).pre("find", autoPopulatePost);

const Post = mongoose.model("Post", postSchema);
module.exports = Post;
