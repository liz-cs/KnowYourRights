const mongoose = require("mongoose");
const validator = require("validator");
const bcrypt = require("bcryptjs");
const baseModel = require("./baseModel");

var userSchema = new baseModel(
  {
    username: {
      type: String,
      required: [true, "Please fill username"]
    },
    firstName: {
      type: String,
      required: [true, "Please fill first name"]
    },
    lastName: {
      type: String,
      required: [true, "Please fill last name"]
    },
    gender: {
      type: String,
      required: [true, "Please choose gender"],
      enum: ["None", "Male", "Female"],
      default: "None"
    },
    email: {
      type: String,
      required: [true, "Please fill email"],
      unique: true,
      lowercase: true,
      validate: [validator.isEmail, "Please provide a valid email address"]
    },
    password: {
      type: String,
      required: [true, "Please fill password"],
      minlength: 6,
      select: false
    },
    passwordConfirm: {
      type: String,
      required: [true, "Please fill password confirm"],
      validate: {
        validator: function(el) {
          return el === this.password;
        },
        message: "Your password and confirmation password doesn't match"
      }
    },
    role: {
      type: String,
      enum: ["admin", "user"], //can be dynamically, analyse
      default: "user"
    }
  },
  { versionKey: false }
);

userSchema.pre("save", async function(next) {
  if (!this.isModified("password")) {
    return next();
  }

  this.password = await bcrypt.hash(this.password, 12);

  this.passwordConfirm = undefined;
  next();
});

userSchema.methods.correctPassword = async (typedPassword, orginalPassword) => {
  return await bcrypt.compare(typedPassword, orginalPassword);
};

const User = mongoose.model("User", userSchema);
module.exports = User;
