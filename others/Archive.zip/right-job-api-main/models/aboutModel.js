const mongoose = require("mongoose");
const baseModel = require("./baseModel");

var aboutSchema = new baseModel({
  title: {
    type: String
  },
  content: {
    type: String
  },
  website: {
    type: String
  },
  facebook: {
    type: String
  },
  instagram: {
    type: String
  },
  linkedin: {
    type: String
  }
});

const About = mongoose.model("About", aboutSchema);
module.exports = About;
