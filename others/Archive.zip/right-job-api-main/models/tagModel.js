const mongoose = require("mongoose");
const baseModel = require("./baseModel");

var tagSchema = new baseModel({
  name: {
    type: String,
    required: [true, "Category is required"]
  }
});

const Tag = mongoose.model("Tag", tagSchema);
module.exports = Tag;
