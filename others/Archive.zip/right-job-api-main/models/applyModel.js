const mongoose = require("mongoose");
const baseModel = require("./baseModel");

var applySchema = new baseModel(
    {
        post: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Post",
            required: [true, "Post is required"]
        },
        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: [true, "User is required"]
        }
    },
    { versionKey: false }
);

var autoPopulateApply = function (next) {
    this.populate("post");
    this.populate("user");
    next();
};

applySchema.pre("findOne", autoPopulateApply).pre("find", autoPopulateApply);

const Apply = mongoose.model("Apply", applySchema);
module.exports = Apply;
