var db = require('mongoose');

module.exports = function (paths) {
    var schema = new db.Schema({
        isActive: {
            type: Boolean,
            default: true
        },
        isDeleted: {
            type: Boolean,
            default: false
        },
    },
        {
            timestamps: {
                createdAt: 'created_at',
                updatedAt: 'updated_at'
            }
        });

    schema.add(paths);

    return schema;
};