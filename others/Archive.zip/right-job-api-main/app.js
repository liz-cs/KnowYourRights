const express = require("express");
const helmet = require("helmet");
const mongoSanitize = require("express-mongo-sanitize");
const xss = require("xss-clean");
const hpp = require("hpp");
const cors = require("cors");
const httpLogger = require('./middlewares/httpLogger');
const logger = require('./utils/logger');
const fileUpload = require('express-fileupload');
const compression = require('compression')
const expressStaticGzip = require("express-static-gzip");

const userRouters = require("./routers/userRouters");
const organizationRouters = require("./routers/organizationRouters");
const postRouters = require("./routers/postRouters");
const categoryRouters = require("./routers/categoryRouters");
const tagRouters = require("./routers/tagRouters");
const aboutRouters = require("./routers/aboutRouters");
const contactRouters = require("./routers/contactRouters");
const authRouters = require("./routers/authRouters");
const applyRouters = require("./routers/applyRouters");
const globalErrHandler = require("./controllers/errorController");
const fileRouters = require("./routers/fileRouters")
const AppError = require("./utils/appError");
const app = express();
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./swagger.json');

app.use('/api/doc', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use(fileUpload({
    createParentPath: true
}));
app.use(cors());
app.use(helmet());
app.use(compression())

// app.use(express.static('uploads'));
app.use("/assets", expressStaticGzip("uploads"));

app.use(httpLogger);

app.use(express.json({
    limit: "15kb"
}));

app.use(mongoSanitize());
app.use(xss());
app.use(hpp());

//routers
app.use("/api/auth", authRouters);
app.use("/api/user", userRouters);
app.use("/api/post", postRouters);
app.use("/api/category", categoryRouters);
app.use("/api/organization", organizationRouters);
app.use("/api/tag", tagRouters);
app.use("/api/about", aboutRouters);
app.use("/api/contact", contactRouters);
app.use("/api/apply", applyRouters);
app.use("/api/asset",fileRouters)

app.use("*", (req, res, next) => {
    const err = new AppError(404, "fail", "undefined route");
    logger.error(`undefined route: ${req.baseUrl}`);
    next(err, req, res, next);
})

app.use(globalErrHandler);

module.exports = app;