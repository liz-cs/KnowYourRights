var Contact = require("../models/contactModel");
const base = require("./baseController");

exports.getAllContacts = base.getAll(Contact);
exports.getContact = base.getOne(Contact);

exports.insertContact = base.createOne(Contact);
exports.updateContact = base.updateOne(Contact);
exports.deleteContact = base.deleteOne(Contact);
