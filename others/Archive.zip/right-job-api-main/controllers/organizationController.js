var Organization = require("../models/organizationModel");
const base = require("./baseController");

exports.getAllOrganizations = base.getAll(Organization);
exports.getOrganization = base.getOne(Organization);

exports.insertOrganization = base.createOne(Organization);
exports.updateOrganization = base.updateOne(Organization);
exports.deleteOrganization = base.deleteOne(Organization);