var User = require("../models/userModel");
const base = require("./baseController");
const logger = require("../utils/logger");

exports.deleteMe = async (req, res, next) => {
  try {
    await User.findByIdAndUpdate(req.user.id, {
      active: false
    });

    res.status(200).json({
      status: "success",
      isSuccess: true,
      data: null
    });
  } catch (error) {
    logger.error(error.message);
    next(error);
  }
};

exports.getUserInfo = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);

    user.password = null;
    user.created_at = null;
    user.updated_at = null;

    res.status(200).json({
      status: "success",
      isSuccess: true,
      data: {
        user: {
          _id: user._id,
          username: user.username,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          gender: user.gender,
          role: user.role
        }
      }
    });
  } catch (error) {
    logger.error(error.message);
    next(error);
  }
};

exports.getAllUsers = base.getAll(User);
exports.getUser = base.getOne(User);

exports.updateUser = base.updateOne(User);
exports.deleteUser = base.deleteOne(User);
