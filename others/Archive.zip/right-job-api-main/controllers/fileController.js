var fs = require('fs');
var path = require('path'); // add path module

exports.upload = async (req, res) => {
    try {
        if (!req.files) {
            res.send({
                status: false,
                message: 'No file uploaded'
            });
            return
        }
        let file = req.files.file;

        file.mv('./uploads/' + req.files.file.name);

        //push file details
        data = {
            name: file.name,
            mimetype: file.mimetype,
            size: file.size
        }
        res.send({
            message: 'File is uploaded',
            data: data
        });

    }
    catch (err) {
        console.log("error ",err)
        res.status(500).send(err);
    }

}

exports.read = async (req, res) => {
    try {
        const dirname = path.resolve('.') + '/uploads/';
        const file = req.body.file;
        let filePath = dirname + file;
        const img = fs.readFileSync(filePath);
        const test = path.basename(filePath);
        res.writeHead(200, { 'Content-Type': test });
        res.end(img);
    }
    catch (err) {
        res.status(500).send(err);
    }
}

