const { promisify } = require("util");
const jwt = require("jsonwebtoken");
var User = require("../models/userModel");
const AppError = require("../utils/appError");
const logger = require("../utils/logger");

const createToken = id => {
  return jwt.sign(
    {
      id
    },
    process.env.JWT_SECRET,
    {
      expiresIn: process.env.JWT_EXPIRES_IN
    }
  );
};

exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      //return next(new AppError(404, "fail", "Please provide email and password"));
      res.status(200).json({
        status: "fail",
        isSuccess: false,
        error: {
          message: "Please provide email and password"
        }
      });
    }

    const user = await User.findOne({ email }).select("+password");

    if (!user || !(await user.correctPassword(password, user.password))) {
      //return next(new AppError(401, "fail", "Email or Password is wrong"));
      res.status(200).json({
        status: "fail",
        isSuccess: false,
        error: {
          message: "Email or Password is wrong"
        }
      });
      return;
    }

    const token = createToken(user.id);

    user.password = undefined;

    res.status(200).json({
      status: "success",
      isSuccess: true,
      token,
      data: {
        user
      }
    });
  } catch (error) {
    logger.error(error.message);
    next(error);
  }
};

exports.signup = async (req, res, next) => {
  try {
    const hasUser = await User.findOne({ email: req.body.email });

    if (hasUser) {
      return next(
        new AppError(409, "fail", "Email address already registered"),
        req,
        res,
        next
      );
    }

    const user = await User.create({
      username: req.body.username,
      name: req.body.name,
      email: req.body.email,
      password: req.body.password,
      passwordConfirm: req.body.passwordConfirm,
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      role: req.body.role
    });

    //const token = createToken(user.id);

    user.password = undefined;

    res.status(200).json({
      status: "success",
      isSuccess: true,
      //token,
      data: {
        user
      }
    });
  } catch (error) {
    logger.error(error.message);
    next(error);
  }
};

exports.protect = async (req, res, next) => {
  try {
    let token;
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith("Bearer")
    ) {
      token = req.headers.authorization.split(" ")[1];
    }
    if (!token) {
      return next(
        new AppError(
          401,
          "fail",
          "You are not logged in! Please login to continue"
        ),
        req,
        res,
        next
      );
    }

    const decode = await promisify(jwt.verify)(token, process.env.JWT_SECRET);
    const user = await User.findById(decode.id);

    if (!user) {
      return next(
        new AppError(401, "fail", "This user is no longer exits"),
        req,
        res,
        next
      );
    }

    req.user = user;

    next();
  } catch (error) {
    logger.error(error.message);
    next(error);
  }
};

exports.restrictTo = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return next(
        new AppError(403, "fail", "You are not allowed to do this action"),
        req,
        res,
        next
      );
    }
    next();
  };
};
