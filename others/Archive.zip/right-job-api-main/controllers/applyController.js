var Apply = require("../models/applyModel");
const base = require("./baseController");

exports.checkDublicateApplyByUser = async (req, res, next) => {
    try {
        const doc = await Apply.find({
            isDeleted: false,
            post: req.body.post,
            user: req.body.user
        }).exec();

        res.status(200).json({
            status: 200,
            isSuccess: true,
            result: {
                data: doc
            }
        });
    } catch (error) {
        logger.error(error.message);
        next(error);
    }
};


exports.getAppliesByUser = async (req, res, next) => {
    try {
        const doc = await Apply.find({
            isDeleted: false,
            user: req.body.user
        }).exec();

        res.status(200).json({
            status: 200,
            isSuccess: true,
            result: {
                data: doc
            }
        });
    } catch (error) {
        logger.error(error.message);
        next(error);
    }
};

exports.getAllApply = base.getAll(Apply);
exports.getApply = base.getOne(Apply);

exports.insertApply = base.createOne(Apply);
exports.updateApply = base.updateOne(Apply);
exports.deleteApply = base.deleteOne(Apply);
