var Tag = require("../models/tagModel");
const base = require("./baseController");

exports.getAllTags = base.getAll(Tag);
exports.getTag = base.getOne(Tag);

exports.insertTag = base.createOne(Tag);
exports.updateTag = base.updateOne(Tag);
exports.deleteTag = base.deleteOne(Tag);
