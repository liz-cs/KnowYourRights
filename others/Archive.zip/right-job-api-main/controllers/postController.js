var Post = require("../models/postModel");
const base = require("./baseController");
const AppError = require("../utils/appError");
const ApiFeatures = require("../utils/apiFeatures");
const logger = require("../utils/logger");

exports.getPostsByFilter = async (req, res, next) => {
  try {
    req.body.isDeleted = false;
    const features = new ApiFeatures(Post.find(req.body), req.query)
      .sort()
      .paginate();
    const doc = await features.query;

    res.status(200).json({
      status: 200,
      isSuccess: true,
      result: {
        data: doc
      }
    });
  } catch (error) {
    logger.error(error.message);
    next(error);
  }
};


exports.getPostsPopular = async (req, res, next) => {
  try {
    req.body.isDeleted = false;
    const doc = await Post.find(req.body).sort({ viewCount: -1 }).limit(5).exec();

    res.status(200).json({
      status: 200,
      isSuccess: true,
      result: {
        data: doc
      }
    });
  } catch (error) {
    logger.error(error.message);
    next(error);
  }
};

exports.getPostsRecently = async (req, res, next) => {
  try {
    req.body.isDeleted = false;
    const doc = await Post.find(req.body).sort({ created_at: 1 }).limit(5).exec();

    res.status(200).json({
      status: 200,
      isSuccess: true,
      result: {
        data: doc
      }
    });
  } catch (error) {
    logger.error(error.message);
    next(error);
  }
};


exports.getPostsByTitle = async (req, res, next) => {
  try {
    req.body.isDeleted = false;
    const features = new ApiFeatures(
      Post.find({ title: { $regex: req.body.title, $options: "i" } }),
      req.query
    )
      .sort()
      .paginate();
    const doc = await features.query;

    res.status(200).json({
      status: 200,
      isSuccess: true,
      result: {
        data: doc
      }
    });
  } catch (error) {
    logger.error(error.message);
    next(error);
  }
};

exports.getAllPosts = base.getAll(Post);
exports.getPost = base.getOne(Post);
exports.insertPost = base.createOne(Post);

exports.updatePost = base.updateOne(Post);
exports.deletePost = base.deleteOne(Post);
