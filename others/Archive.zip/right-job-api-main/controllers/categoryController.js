var Category = require("../models/categoryModel");
const base = require("./baseController");

exports.getAllCategories = base.getAll(Category);
exports.getCategory = base.getOne(Category);

exports.insertCategory = base.createOne(Category);
exports.updateCategory = base.updateOne(Category);
exports.deleteCategory = base.deleteOne(Category);