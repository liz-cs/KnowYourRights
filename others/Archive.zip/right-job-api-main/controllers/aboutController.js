var About = require("../models/aboutModel");
const base = require("./baseController");

exports.getAllAbouts = base.getAll(About);
exports.getAbout = base.getOne(About);

exports.insertAbout = base.createOne(About);
exports.updateAbout = base.updateOne(About);
exports.deleteAbout = base.deleteOne(About);
