const mongoose = require("mongoose");
const app = require("./app");
const dotenv = require("dotenv");
const logger = require("./utils/logger");

dotenv.config({
    path: "./config.env"
})

process.on("uncaughtException", err => {
    console.log("UNCAUGHT EXCEPTION!!! shutting down...");
    logger.error(`UNCAUGHT REJECTON!!! shutting down: ${err.name, err.message}`);
    process.exit(1);
})

const database = process.env.DATABASE.replace("<PASSWORD>", process.env.DATABASE_PASSWORD);

mongoose.connect(database, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false
}).then(con => {
    console.log("DB connection successfully!");
})

const port = process.env.PORT;

app.listen(port, () => {
    console.log(`Application is running on port ${port}`);
})

process.on("unhandleRejection", err => {
    console.log("UNHANDLED REJECTON!!! shutting down...");
    logger.error(`UNHANDLED REJECTON!!! shutting down: ${err.name, err.message}`);
    server.close(() => {
        process.exit(1);
    })
})